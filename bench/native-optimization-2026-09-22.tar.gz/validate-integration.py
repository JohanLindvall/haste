from pathlib import Path
import os
import subprocess
import time

ROOT = Path('/home/azureuser/haste')
OUT = Path('/tmp/haste-perf-20260922')
base_env = dict(os.environ, GOMAXPROCS='2')

def check(name, args, cwd=ROOT, extra_env=None):
    print(time.strftime('%H:%M:%S'), name, flush=True)
    env = dict(base_env, **(extra_env or {}))
    result = subprocess.run(args, cwd=cwd, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / ('validation-integration-' + name + '.txt')).write_text(result.stdout)
    if result.returncode:
        print(result.stdout, flush=True)
        raise SystemExit(result.returncode)
    return result.stdout

check('native', ['go', 'test', './...'])
check('purego', ['go', 'test', '-tags=purego', './...'])
check('race', ['go', 'test', '-race', './...'])
check('purego-race', ['go', 'test', '-race', '-tags=purego', './...'])
check('go121', ['go', 'test', './...'], extra_env={'GOTOOLCHAIN': 'go1.21.13'})
check('vet', ['go', 'vet', './...'])
check('bench', ['go', 'test', '-v', './...'], ROOT / 'bench')
packages = check('packages', ['go', 'list', '-f', '{{if .TestGoFiles}}{{.ImportPath}}{{end}}', './...']).split()
if not packages:
    raise SystemExit('no test packages discovered')
targets = ['linux/' + arch for arch in ['386', 'arm', 'mips', 'mipsle', 'mips64', 'mips64le', 's390x', 'ppc64', 'ppc64le', 'riscv64', 'loong64', 'arm64', 'amd64']]
targets += ['windows/amd64', 'windows/arm64', 'darwin/amd64', 'darwin/arm64', 'freebsd/amd64']
for target in targets:
    system, arch = target.split('/')
    for pkg in packages:
        check('cross-' + target.replace('/', '-') + '-' + pkg.rsplit('/', 1)[-1],
              ['go', 'test', '-c', '-o', '/dev/null', pkg],
              extra_env={'GOOS': system, 'GOARCH': arch})
check('wasm', ['go', 'build', './...'], extra_env={'GOOS': 'js', 'GOARCH': 'wasm'})
print(time.strftime('%H:%M:%S'), 'integration validation passed', flush=True)
