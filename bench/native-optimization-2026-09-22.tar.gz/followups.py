from run import ROOT, OUT, run
import subprocess
for round in range(3):
    for variant in (['before','after'] if round%2==0 else ['after','before']):
        for package in ['xxh3','xxh64','rapidhash']:
            run(package+'-final-'+variant, '^Benchmark(Sum64|Sum128)$/^(16384|1048576)$', package+'-large-'+variant+'-'+str(round), '300ms', 2)
subprocess.run(['go','test','-overlay='+str(OUT/'branch-overlay.json'),'-c','-o',str(OUT/'branch.test'),'./xxh3'],cwd=ROOT,check=True)
run('branch','^BenchmarkBranchOrder$', 'branch-order', '100ms', 3)
print('follow-up measurements complete',flush=True)
