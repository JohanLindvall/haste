import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/azureuser/haste')
OUT = Path('/tmp/haste-perf-20260922')
env = dict(os.environ, GOMAXPROCS='1')

def run(binary, pattern, name, duration='50ms', count=1):
    command = ['taskset', '-c', '1', str(OUT / (binary + '.test')),
               '-test.run=^$', '-test.bench=' + pattern,
               '-test.benchtime=' + duration, '-test.count=' + str(count),
               '-test.benchmem']
    print(time.strftime('%H:%M:%S'), name, flush=True)
    with (OUT / (name + '.txt')).open('w') as output:
        subprocess.run(command, cwd=ROOT, env=env, stdout=output,
                       stderr=subprocess.STDOUT, check=True)

if __name__ == '__main__':
    revision = sys.argv[1]
    for package in ['xxh3', 'xxh64', 'rapidhash']:
        run(package + '-' + revision, '.', package + '-screen-' + revision)
    for package in ['xxh3', 'xxh64', 'rapidhash']:
        run(package + '-pure-' + revision, 'Benchmark(Sum|Digest|Fixed)',
            package + '-pure-screen-' + revision)
    run('compare-' + revision, 'BenchmarkCompare', 'compare-screen-' + revision)
