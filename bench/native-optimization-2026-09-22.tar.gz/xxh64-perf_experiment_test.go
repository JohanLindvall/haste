package xxh64

import (
	"fmt"
	"testing"
	"unsafe"
)

func (d *Digest) Sum64Before() uint64 {
	var h uint64
	if d.total >= blockLen {
		v := d.v
		h = mergeLanes(&v)
	} else {
		h = d.seed + prime5
	}
	return finalize(h+d.total, unsafe.Pointer(&d.buf), d.n)
}

func BenchmarkExperimentSum(b *testing.B) {
	for _, n := range []int{0, 4, 8, 16, 31, 32, 33, 64, 128, 240, 241, 256, 576, 1024, 1025, 4096} {
		d := NewSeed(42)
		d.Write(testBuffer(n))
		b.Run(fmt.Sprint(n), func(b *testing.B) {
			b.Run("64/Before", func(b *testing.B) {
				for i := 0; i < b.N; i++ {
					sink = d.Sum64Before()
				}
			})
			b.Run("64/After", func(b *testing.B) {
				for i := 0; i < b.N; i++ {
					sink = d.Sum64()
				}
			})
		})
	}
}
