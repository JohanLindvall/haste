package xxh3

import (
	"fmt"
	"testing"
	"unsafe"
)

func (d *Digest) digestLongBefore(acc *[accNB]uint64) {
	*acc = d.acc

	// Whole stripes can only still be staged for a message that never reached
	// the staging capacity; past that, absorb leaves at most a partial one.
	// Where they leave the block position does not matter: only the final
	// stripe follows, and it is keyed from the end of the secret.
	// bufUsed is at least one here: totalLen is past midsizeMax, and absorb
	// never leaves the staging area empty.
	if nb := int(uint(d.bufUsed-1) / stripeLen); nb > 0 {
		d.consumeStripesBefore(acc, unsafe.Pointer(&d.buf[stripeLen]), nb, d.nbStripesSoFar)
	}

	// The final stripe is the last 64 bytes of the message. The window sits
	// directly in front of the staged bytes, so those 64 bytes are contiguous
	// at buf[bufUsed:] wherever the boundary happens to fall.
	accumStripes(acc, add(unsafe.Pointer(&d.buf), uintptr(d.bufUsed)), 1,
		add(d.secretPtr(), uintptr(d.secretLimit-secretLastAccStart)))
}

func (d *Digest) Sum64Before() uint64 {
	if d.totalLen > midsizeMax {
		var acc [accNB]uint64
		d.digestLongBefore(&acc)
		return mergeAccs(&acc, add(d.secretPtr(), secretMergeAccsStart), d.totalLen*prime64_1)
	}
	if d.useSeed {
		return sum64(unsafe.Pointer(&d.buf[stripeLen]), uintptr(d.totalLen),
			unsafe.Pointer(&kSecret), secretDefaultSize, d.seed)
	}
	return sum64NS(unsafe.Pointer(&d.buf[stripeLen]), uintptr(d.totalLen),
		d.secretPtr(), d.secretLimit+stripeLen)
}

func (d *Digest) Sum128Before() Uint128 {
	if d.totalLen > midsizeMax {
		var acc [accNB]uint64
		d.digestLongBefore(&acc)
		sec := d.secretPtr()
		return Uint128{
			Lo: mergeAccs(&acc, add(sec, secretMergeAccsStart), d.totalLen*prime64_1),
			Hi: mergeAccs(&acc, add(sec, uintptr(d.secretLimit+stripeLen-8*accNB-secretMergeAccsStart)),
				^(d.totalLen * prime64_2)),
		}
	}
	if d.useSeed {
		return sum128(unsafe.Pointer(&d.buf[stripeLen]), uintptr(d.totalLen),
			unsafe.Pointer(&kSecret), secretDefaultSize, d.seed)
	}
	return sum128NS(unsafe.Pointer(&d.buf[stripeLen]), uintptr(d.totalLen),
		d.secretPtr(), d.secretLimit+stripeLen)
}

func BenchmarkExperimentSum(b *testing.B) {
	for _, mode := range []struct {
		name string
		new  func() *Digest
	}{{"Default", New}, {"Seed", func() *Digest { return NewSeed(42) }}, {"Secret", func() *Digest { return NewSecret(testSecret(137)) }}} {
		b.Run(mode.name, func(b *testing.B) {
			for _, n := range []int{0, 4, 8, 16, 31, 32, 33, 64, 128, 240, 241, 256, 576, 1024, 1025, 1536, 4096} {
				d := mode.new()
				writeInChunks(d, testBuffer(n), stripeLen)
				b.Run(fmt.Sprint(n), func(b *testing.B) {
					b.Run("64/Before", func(b *testing.B) {
						for i := 0; i < b.N; i++ {
							sink64 = d.Sum64Before()
						}
					})
					b.Run("64/After", func(b *testing.B) {
						for i := 0; i < b.N; i++ {
							sink64 = d.Sum64()
						}
					})
					b.Run("128/Before", func(b *testing.B) {
						for i := 0; i < b.N; i++ {
							sink128 = d.Sum128Before()
						}
					})
					b.Run("128/After", func(b *testing.B) {
						for i := 0; i < b.N; i++ {
							sink128 = d.Sum128()
						}
					})
				})
			}
		})
	}
}

func (d *Digest) consumeStripesBefore(acc *[accNB]uint64, in unsafe.Pointer, nbStripes, soFar int) int {
	accumBlocks(acc, in, nbStripes, d.secretPtr(), d.secretLimit, soFar)
	return d.wrap(soFar + nbStripes)
}
