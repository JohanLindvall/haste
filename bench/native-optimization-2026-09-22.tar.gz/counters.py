import os
from pathlib import Path
import subprocess

OUT = Path('/tmp/haste-perf-20260922')
ROOT = Path('/home/azureuser/haste')
cases = [
    ('xxh3', '^BenchmarkDigestSum$/^Default$/^256$/^64$', 'xxh3-sum-256'),
    ('xxh3', '^BenchmarkDigestSum$/^Default$/^1536$/^64$', 'xxh3-sum-1536'),
    ('xxh64', '^BenchmarkDigestSum$/^32$', 'xxh64-sum-32'),
]
for package in ['xxh3', 'xxh64', 'rapidhash']:
    for n in [4, 64, 256, 1024, 16384]:
        cases.append((package, f'^BenchmarkSum64$/^{n}$', f'{package}-oneshot-{n}'))
for package, pattern, name in cases:
    variants = ['before', 'after'] if '-sum-' in name else ['after']
    for variant in variants:
        print(name, variant, flush=True)
        result = subprocess.run([
            str(OUT / 'pstat'), '-bin', str(OUT / (package + '-final-' + variant + '.test')),
            '-bench', pattern, '-core', '1', '-groups', 'core', '-benchtime', '300ms'],
            cwd=ROOT, env=dict(os.environ, GOMAXPROCS='1'), text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (OUT / ('counters-' + name + '-' + variant + '.txt')).write_text(result.stdout)
        if result.returncode:
            print(result.stdout, flush=True)
            raise SystemExit(result.returncode)
