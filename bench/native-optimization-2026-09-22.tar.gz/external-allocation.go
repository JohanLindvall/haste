package main
import (
 "fmt"
 "testing"
 "github.com/JohanLindvall/haste/xxh3"
)
var sink uint64
func main() {
 input := make([]byte, 4096)
 secret := make([]byte, 193)
 seeded := testing.AllocsPerRun(1000, func() { d:=xxh3.NewSeed(42); d.Write(input); sink=d.Sum64() })
 custom := testing.AllocsPerRun(1000, func() { d:=xxh3.NewSecret(secret); d.Write(input); sink=d.Sum64() })
 fmt.Printf("external caller: NewSeed %.0f allocs/op; NewSecret %.0f allocs/op\n", seeded, custom)
 if seeded != 0 || custom != 0 { panic("unexpected digest allocation") }
}
