import csv
from pathlib import Path
import re
import statistics

OUT = Path('/tmp/haste-perf-20260922')
ROOT = Path('/home/azureuser/haste')

def parse(paths):
    cells = {}
    for path in paths:
        for line in path.read_text().splitlines():
            parts = line.split()
            if not parts or not parts[0].startswith('Benchmark') or 'ns/op' not in parts:
                continue
            def unit(name):
                return float(parts[parts.index(name)-1]) if name in parts else 0
            name = re.sub(r'-\d+$', '', parts[0])
            cells.setdefault(name, []).append({
                'ns': unit('ns/op'), 'bytes': unit('B/op'), 'allocs': unit('allocs/op')})
    return cells

def median(samples, field='ns'):
    return statistics.median(sample[field] for sample in samples)

def collect():
    rows = []
    for package in ['xxh3', 'xxh64', 'rapidhash']:
        for build in ['native', 'purego']:
            sides = {}
            for variant in ['before', 'after']:
                if build == 'native':
                    paths = list(OUT.glob(f'{package}-measure-{variant}-*.txt'))
                    paths += list(OUT.glob(f'{package}-control-{variant}.txt'))
                else:
                    paths = list(OUT.glob(f'{package}-pure-measure-{variant}.txt'))
                    paths += list(OUT.glob(f'{package}-pure-local-{variant}.txt'))
                sides[variant] = parse(paths)
            for name, before in sides['before'].items():
                if name not in sides['after']:
                    continue
                after = sides['after'][name]
                if len(before) != 6 or len(after) != 6:
                    continue
                a, b = median(before), median(after)
                rows.append({
                    'package': package, 'build': build, 'benchmark': name,
                    'before_ns': round(a, 4), 'after_ns': round(b, 4),
                    'change_pct': round((b/a-1)*100, 3),
                    'before_B_op': median(before, 'bytes'),
                    'after_B_op': median(after, 'bytes'),
                    'before_allocs_op': median(before, 'allocs'),
                    'after_allocs_op': median(after, 'allocs'),
                    'samples_per_revision': len(before),
                    'before_min_ns': min(x['ns'] for x in before),
                    'before_max_ns': max(x['ns'] for x in before),
                    'after_min_ns': min(x['ns'] for x in after),
                    'after_max_ns': max(x['ns'] for x in after),
                })
    return rows

if __name__ == '__main__':
    rows = collect()
    if rows:
        path = ROOT / 'bench/native-optimization-2026-09-22.csv'
        with path.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys(), lineterminator='\n')
            writer.writeheader()
            writer.writerows(rows)
    for row in rows:
        if row['build'] != 'native':
            continue
        name = row['benchmark']
        if name.startswith('BenchmarkDigestLocal') or re.match(r'BenchmarkDigestSum/Default/(256|1024|1536|4096)/', name) or name in ['BenchmarkDigestSum/32', 'BenchmarkDigest/256', 'BenchmarkDigest/1024']:
            print(row['package'], name, row['before_ns'], row['after_ns'], row['change_pct'], 'allocs:', row['before_allocs_op'], row['after_allocs_op'])
    print('Complete repeated cells:', len(rows))
