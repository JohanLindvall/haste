from pathlib import Path
import json
import os
import subprocess
import sys
import time
from run import ROOT, OUT, run

def build():
    replacements = {}
    for relative in ['xxh3/digest.go', 'xxh64/digest.go', 'internal/asmgen/arm64_rapid.go']:
        original = OUT / 'original' / relative
        original.parent.mkdir(parents=True, exist_ok=True)
        original.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=ROOT))
        replacements[str(ROOT / relative)] = str(original)
    overlay = OUT / 'before-overlay.json'
    overlay.write_text(json.dumps({'Replace': replacements}))
    for variant in ['before', 'after']:
        options = ['-overlay=' + str(overlay)] if variant == 'before' else []
        for package in ['xxh3', 'xxh64', 'rapidhash']:
            for pure in [False, True]:
                name = package + ('-pure' if pure else '') + '-final-' + variant
                tags = ['-tags=purego'] if pure else []
                subprocess.run(['go', 'test', *options, *tags, '-c', '-o', str(OUT / (name + '.test')), './' + package], cwd=ROOT, check=True)
        subprocess.run(['go', 'test', *options, '-c', '-o', str(OUT / ('compare-final-' + variant + '.test')), '.'], cwd=ROOT / 'bench', check=True)
    print('Built baseline and candidate with identical benchmark sources', flush=True)

def measure():
    # Three paired rounds, alternating order, two samples per round.
    for round in range(3):
        order = ['before', 'after'] if round % 2 == 0 else ['after', 'before']
        for variant in order:
            for package in ['xxh3', 'xxh64']:
                run(package + '-final-' + variant, '^Benchmark(NewSeed|Digest(Sum|Chunked|Local)?)$',
                    f'{package}-measure-{variant}-{round}', '300ms', 2)
    for variant in ['before', 'after']:
        run('xxh3-pure-final-' + variant,
            '^BenchmarkDigestSum$/^Default$/^(16|64|241|256|576|1024|1025|1536|4096)$',
            'xxh3-pure-measure-' + variant, '150ms', 6)
        run('xxh64-pure-final-' + variant, '^BenchmarkDigestSum$',
            'xxh64-pure-measure-' + variant, '150ms', 6)
        run('xxh3-pure-final-' + variant, '^BenchmarkDigestLocal$',
            'xxh3-pure-local-' + variant, '150ms', 6)
        for package in ['xxh3', 'xxh64', 'rapidhash']:
            run(package + '-final-' + variant,
                '^Benchmark(Sum64|Sum128|Sum64Seed)$/^(4|16|64|256|1024|16384|1048576)$',
                package + '-control-' + variant, '150ms', 6)
    run('compare-final-after',
        '^BenchmarkCompare(64|128|StreamChunk)$/^(4|16|64|256|1024|16384|65536)$/^(haste-xxh3|zeebo|haste-xxh64|cespare-xxh64|haste-rapid|dw1-rapid|cespare)$',
        'compare-final', '150ms', 6)
    # Recheck the complete API and backend screen after the focused measurements.
    for package in ['xxh3', 'xxh64', 'rapidhash']:
        run(package + '-final-after', '.', package + '-screen-after')
        run(package + '-pure-final-after', '^Benchmark(Sum|Digest|Fixed)',
            package + '-pure-screen-after')
    print(time.strftime('%H:%M:%S'), 'measurements complete', flush=True)

if sys.argv[1] == 'build':
    build()
else:
    measure()
